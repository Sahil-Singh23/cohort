## Typescript Assignment

Your task is to convert course selling application into typescript.