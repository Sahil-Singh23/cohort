
# BG-Color-Changer

Your task is to design and implement a Bg-Color-Changer application that meets the following requirements:

- The UI should resemble the example shown below..

![Image](https://utfs.io/f/7e57da15-803c-48c7-8487-dcade58eef91-wx71zg.png)


- When user clicks on a red button, the background color should change to red.


- User should also be able to add custom colors to the color panel.


### Don't copy UI as it is, only take reference from it.