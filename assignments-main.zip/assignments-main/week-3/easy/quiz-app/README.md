
# Quiz-App

Your task is to design and implement a Quiz application that meets the following requirements:

- The UI should resemble the example shown [here](https://utfs.io/f/032c6baa-e76a-4e26-b6b2-f6a105c15f03-pym7du.webm)

- display the result after submitting the quiz.

- you don't need to use api or backend, use data mentioned in `data.js`


### Don't copy UI as it is, only take reference from it.