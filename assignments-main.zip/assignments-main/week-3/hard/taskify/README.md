
# Taskify

- Create a Task Management Application with drag-drop functionality between the category.

- you can avoid time, and type of TODO (easy, medium, hard).


- The UI should resemble the example shown below..

![Image](https://utfs.io/f/c63f4dc5-6833-4c65-9b07-e1421d833ee2-ng18dw.png)



### Don't copy UI as it is, only take reference from it.



