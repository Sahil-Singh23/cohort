
# Form-Builder

- Your task is to a form builder that allows users to add different types of input fields dynamically. Include options for text inputs, checkboxes, and radio buttons. Each added field should be displayed in a preview area.


- The UI should resemble the example shown below..

![Image](https://utfs.io/f/9174ecc0-b9c4-454c-9db6-2d6f1ed6138d-ng35bm.png)



### Don't copy UI as it is, only take reference from it.



