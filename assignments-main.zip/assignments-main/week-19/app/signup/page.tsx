import {Signup} from "@/components/Signup"
export default function() {
    return <Signup />
}