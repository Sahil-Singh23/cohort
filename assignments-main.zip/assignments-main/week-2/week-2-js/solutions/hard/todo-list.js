class Todo {
    constructor() {
      this.todos = [];
    }
  
    add(todo) {
      this.todos.push(todo);
    }
  
    remove(indexOfTodo) {
      if (indexOfTodo >= 0 && indexOfTodo < this.todos.length) {
        this.todos.splice(indexOfTodo, 1);
      }
    }
  
    update(index, updatedTodo) {
      if (index >= 0 && index < this.todos.length) {
        this.todos[index] = updatedTodo;
      }
    }
  
    getAll() {
      return this.todos;
    }
  
    get(indexOfTodo) {
      if (indexOfTodo >= 0 && indexOfTodo < this.todos.length) {
        return this.todos[indexOfTodo];
      }
      return null;
    }
  
    clear() {
      this.todos = [];
    }
  }
  
  module.exports = Todo;
  