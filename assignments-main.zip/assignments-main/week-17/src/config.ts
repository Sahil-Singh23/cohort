
export const DB_URL = "<add your connection string>";