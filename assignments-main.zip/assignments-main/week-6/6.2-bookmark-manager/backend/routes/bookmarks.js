let bookmarks = []; // in memory space

export async function addBookmark(req,res,next){
// write here
}

export async function deleteBookmark(req,res,next){
// write here
}

export async function getAllBookmarks(req,res,next){
// write here
}