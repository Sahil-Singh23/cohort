import AuthSystem from './components/AuthSystem';
import './Auth.css';

function App() {
  return <AuthSystem />;
}

export default App;
