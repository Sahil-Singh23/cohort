import React from 'react'

const AppBar = () => {
  return (
    <div>AppBar</div>
  )
}

export default AppBar