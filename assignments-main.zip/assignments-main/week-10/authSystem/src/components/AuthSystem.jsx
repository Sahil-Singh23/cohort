import React from 'react'

const AuthSystem = () => {
  return (
    <div>AuthSystem</div>
  )
}

export default AuthSystem