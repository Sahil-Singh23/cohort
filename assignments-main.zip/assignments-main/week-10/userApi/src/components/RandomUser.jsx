import React from 'react'

const RandomUser = () => {
  return (
    <div>RandomUser</div>
  )
}

export default RandomUser