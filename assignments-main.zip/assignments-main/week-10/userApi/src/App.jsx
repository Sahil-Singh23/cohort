import RandomUser from './components/RandomUser'

function App() {

  return (
    <>
      <RandomUser />
    </>
  )
}

export default App
