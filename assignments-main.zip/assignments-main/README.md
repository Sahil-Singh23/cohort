100xdevs Cohort 3 Assignments
