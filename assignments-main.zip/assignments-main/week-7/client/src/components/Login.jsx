// login code here
import axios from 'axios';
import React from 'react'

const Login = () => {
    // call the functions onClick of button.
    async function handleLogin() {
        const resposne = await axios.post(); // // if you don't know about axios, give it a read https://axios-http.com/docs/intro
    }
    return (
        <div>Login</div>
    )
}

export default Login