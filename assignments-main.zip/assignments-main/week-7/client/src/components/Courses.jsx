// courses code here
import React from 'react'

// use axios here, similar to register and login
const Courses = () => {
  return (
    <div>Courses</div>
  )
}

export default Courses