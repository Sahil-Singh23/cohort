// firstly, Don't get overwhelmed and if you are then go with client-easy.
import Home from "./pages/Home"
function App() {

  return (
    <>
      {/* start  writing from here */}
       <Home/>
    </>
  )
}

export default App
