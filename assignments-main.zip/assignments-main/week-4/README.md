### How to test the code ?

suppose I want to test my solution for `week-4/ middlewares/01-requestcount.js`. so go inside `week-4/middlewares` and run this command:

```
npx jest ./tests/01-requestcount.spec.js 
```

format of the command is:
```
npx jest ./tests/<file_name>.spec.js
```