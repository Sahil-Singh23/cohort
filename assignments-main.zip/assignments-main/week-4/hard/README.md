# Taskify Backend

Create Basic Version Backend of Taskify assignment ( week-3 hard ).

### Setup Guide

1. go inside week-4/hard and run:

```
 npm install 
```

2. copy .env.example to .env.
```
cp .env.example .env
```

3. run the server.
```
npm run dev
```