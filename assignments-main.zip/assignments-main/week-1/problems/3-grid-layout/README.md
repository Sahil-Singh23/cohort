
Do the same as the previous problem but use grid instead of flexbox.