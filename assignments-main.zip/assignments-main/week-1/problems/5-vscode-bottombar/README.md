Now try making the bottom bar look like photo.png

![Alt text](photo.png)