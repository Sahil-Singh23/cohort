
Design the landing page of VSCode - https://code.visualstudio.com/

Easy assignment - Only design the top section

Hard Assignment - Design the whole page