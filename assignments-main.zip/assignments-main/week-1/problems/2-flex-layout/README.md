
Create a simple layout where you see div with red color on the left and blue color on the right.
The right grid should be twice as wide as the left one.

Contents of both the grids should be vertically centered

Also make sure its max 1200px and center of the screen