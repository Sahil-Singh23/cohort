
Create a grid layout now that looks like this

1x width                    2x width
---------------------------|--------------------------------
|          Left            |                              |
|  text text text text     |  col 1  |  col 2   |  col 3  |              
|  text text text text     |  col 1  |  col 2   |  col 3  |
|  text text text text     |  col 1  |  col 2   |  col 3  |
|  text text text text     |                              |
|                          |                              |
---------------------------|--------------------------------


![Alt text](photo.png)