
Create a layout where you have a single div in the center of the page with width 1200px.
Hardcode its width to be 1200px.
Hardcode its height to be 500px.