import React, { Component } from 'react'

export class AdopterData extends Component {
  render() {
    return (
      <div>AdopterData</div>
    )
  }
}

export default AdopterData