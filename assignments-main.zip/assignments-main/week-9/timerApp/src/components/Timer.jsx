import React from 'react'

const Timer = () => {
  return (
    <div>Timer</div>
  )
}

export default Timer